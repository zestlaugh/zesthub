import sys
import os
import json
import urllib.parse
import xbmcplugin
import xbmcgui
import xbmcaddon

addon_handle = int(sys.argv[1])
xbmcplugin.setContent(addon_handle, 'videos')

BOOKMARK_FILE = os.path.join(xbmc.translatePath("special://profile/addon_data/plugin.video.animehub"), "bookmarks.json")

def load_bookmarks():
    if not os.path.exists(BOOKMARK_FILE):
        return []
    with open(BOOKMARK_FILE, "r") as f:
        return json.load(f)

def save_bookmarks(bookmarks):
    os.makedirs(os.path.dirname(BOOKMARK_FILE), exist_ok=True)
    with open(BOOKMARK_FILE, "w") as f:
        json.dump(bookmarks, f)

def get_url(**kwargs):
    return sys.argv[0] + '?' + urllib.parse.urlencode(kwargs)

def list_anime():
    # Sample anime data
    anime_list = [
        {'id': 'naruto', 'title': 'Naruto', 'url_sub': 'http://example.com/naruto_sub.mp4', 'url_dub': 'http://example.com/naruto_dub.mp4', 'poster': 'https://upload.wikimedia.org/wikipedia/en/9/94/NarutoCoverTankobon1.jpg'},
        {'id': 'onepiece', 'title': 'One Piece', 'url_sub': 'http://example.com/onepiece_sub.mp4', 'url_dub': 'http://example.com/onepiece_dub.mp4', 'poster': 'https://upload.wikimedia.org/wikipedia/en/6/65/One_Piece_Logo.svg'}
    ]

    # Add Bookmarks link on top
    li = xbmcgui.ListItem(label='⭐ Bookmarked Anime')
    url = get_url(action='bookmarks')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)

    for anime in anime_list:
        title = anime['title']
        anime_id = anime['id']
        poster = anime['poster']
        li = xbmcgui.ListItem(label=title)
        li.setArt({'thumb': poster, 'icon': poster, 'fanart': poster})
        li.setInfo('video', {'title': title})

        # Add context menu for bookmarking
        context_menu = [
            ('⭐ Bookmark this anime', f'RunPlugin({get_url(action="bookmark", id=anime_id, title=title, poster=poster)})')
        ]
        li.addContextMenuItems(context_menu)

        url = get_url(action='select_lang', id=anime_id)
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(addon_handle)

def show_bookmarks():
    bookmarks = load_bookmarks()
    if not bookmarks:
        xbmcgui.Dialog().notification("No Bookmarks", "You haven't bookmarked any anime yet.", xbmcgui.NOTIFICATION_INFO, 2500)
    for anime in bookmarks:
        title = anime['title']
        poster = anime['poster']
        anime_id = anime['id']

        li = xbmcgui.ListItem(label=title)
        li.setArt({'thumb': poster})
        li.setInfo('video', {'title': title})

        url = get_url(action='select_lang', id=anime_id)
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(addon_handle)

def bookmark_anime(anime_id, title, poster):
    bookmarks = load_bookmarks()
    if not any(b['id'] == anime_id for b in bookmarks):
        bookmarks.append({'id': anime_id, 'title': title, 'poster': poster})
        save_bookmarks(bookmarks)
        xbmcgui.Dialog().notification("Bookmarked", f"{title} saved!", xbmcgui.NOTIFICATION_INFO, 2000)
    else:
        xbmcgui.Dialog().notification("Already Bookmarked", f"{title} is already in your list.", xbmcgui.NOTIFICATION_INFO, 2000)

def select_lang(anime_id):
    dialog = xbmcgui.Dialog()
    choice = dialog.select('Choose Language', ['Subbed', 'Dubbed'])
    if choice == -1:
        return
    # For demo, hardcode URLs, but you'd get them dynamically based on anime_id & choice
    if anime_id == 'naruto':
        url = 'http://example.com/naruto_sub.mp4' if choice == 0 else 'http://example.com/naruto_dub.mp4'
        title = 'Naruto'
    elif anime_id == 'onepiece':
        url = 'http://example.com/onepiece_sub.mp4' if choice == 0 else 'http://example.com/onepiece_dub.mp4'
        title = 'One Piece'
    else:
        xbmcgui.Dialog().notification("Error", "Anime not found!", xbmcgui.NOTIFICATION_ERROR, 2500)
        return

    play_video(url, title)

def play_video(url, title):
    play_item = xbmcgui.ListItem(path=url)
    play_item.setInfo('video', {'title': title})
    xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)

def router(params):
    action = params.get('action')
    if action is None:
        list_anime()
    elif action == 'bookmarks':
        show_bookmarks()
    elif action == 'bookmark':
        bookmark_anime(params['id'], params['title'], params['poster'])
    elif action == 'select_lang':
        select_lang(params['id'])
    elif action == 'play':
        play_video(params['url'], params.get('title', 'Unknown'))
    else:
        list_anime()

if __name__ == '__main__':
    params = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
    router(params)
